#!/usr/bin/env python3
import sys
import rospy
from control_demo.msg import SetVelocity
from control_demo.msg import SetSpeed


# 初始化ROS节点
rospy.init_node('controller_demo_node', log_level=rospy.DEBUG)

# 创建底盘控制发布器
set_velocity = rospy.Publisher('/chassis_control/set_velocity', SetVelocity, queue_size=1)
set_speed = rospy.Publisher('/chassis_control/set_speed',  SetSpeed, queue_size=1)


start = True
#关闭前处理
def stop():
    global start

    start = False
    print('关闭中...')
    set_velocity.publish(0,0,0)  # 发布底盘控制消息,停止移动
    

def main():
    print("启动程序...")
    rospy.sleep(1)



    set_velocity.publish(150, 90, 0)# 控制底盘前进，发布底盘控制消息,线速度150，方向角90，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)
    
    set_velocity.publish(150, 270, 0)# 控制底盘后退，发布底盘控制消息,线速度150，方向角270，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)


    set_velocity.publish(150, 180, 0)# 控制底盘左前移，发布底盘控制消息,线速度150，方向角180，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)

    set_velocity.publish(150, 0, 0)# 控制底盘右前移，发布底盘控制消息,线速度150，方向角0，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)

    
    set_velocity.publish(0, 90, -0.3)# # 控制底盘原地左转，发布底盘控制消息,线速度0，方向角90，偏航角速度(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)

    set_velocity.publish(0, 90, 0.3)# # 控制底盘原地右转，发布底盘控制消息,线速度0，方向角90，偏航角速度(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1) 

    set_velocity.publish(150, 135, 0)# 控制底盘左前移，发布底盘控制消息,线速度150，方向角180，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)

    set_velocity.publish(150, 315, 0)# 控制底盘右前移，发布底盘控制消息,线速度150，方向角0，偏航角速度0(大于0，为顺时针方向)
    rospy.sleep(2)
    set_velocity.publish(0, 0, 0)# 停止运动
    rospy.sleep(1)

    set_speed.publish(-150, 150, 0, 0)# # 控制底盘左漂移，发布底盘控制消息,线速度0，方向角270，偏航角速度(大于0，为顺时针方向)
    rospy.sleep(2)
    set_speed.publish(0, 0, 0, 0)# 停止运动
    rospy.sleep(1)

    set_speed.publish(150, -150, 0, 0)# # 控制底盘原右漂移，发布底盘控制消息,线速度0，方向角270，偏航角速度(大于0，为顺时针方向)
    rospy.sleep(2)
    set_speed.publish(0, 0, 0, 0)# 停止运动
    rospy.sleep(1) 



    # set_velocity.publish(200, 270, -0.3)# 控制底盘线性左转前进，发布底盘控制消息,线速度150，方向角90，偏航角速度(大于0，为顺时针方向)
    # rospy.sleep(3)
    # set_velocity.publish(0, 0, 0)# 停止运动
    # rospy.sleep(1)

    # set_velocity.publish(-200, 270, 0.3)# 控制底盘线性左转后退，发布底盘控制消息,线速度150，方向角90，偏航角速度(大于0，为顺时针方向)
    # rospy.sleep(3)
    # set_velocity.publish(0, 0, 0)# 停止运动
    # rospy.sleep(1)
        
    # set_velocity.publish(200, 270, 0.3)# 控制底盘线性右转前进，发布底盘控制消息,线速度150，方向角90，偏航角速度0(大于0，为顺时针方向)
    # rospy.sleep(3)
    # set_velocity.publish(0, 0, 0)# 停止运动
    # rospy.sleep(1)

    # set_velocity.publish(-200, 270, -0.3)# 控制底盘线性右转后退，发布底盘控制消息,线速度150，方向角90，偏航角速度0(大于0，为顺时针方向)
    # rospy.sleep(3)
    # set_velocity.publish(0, 0, 0)# 停止运动
    # rospy.sleep(1)
          
if __name__ == '__main__':
    rospy.on_shutdown(stop)
    main()
    set_velocity.publish(0, 0, 0)  # 清除底盘控制消息

